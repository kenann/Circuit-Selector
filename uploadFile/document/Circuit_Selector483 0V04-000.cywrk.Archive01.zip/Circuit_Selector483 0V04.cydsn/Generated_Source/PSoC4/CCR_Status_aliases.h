/*******************************************************************************
* File Name: CCR_Status.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CCR_Status_ALIASES_H) /* Pins CCR_Status_ALIASES_H */
#define CY_PINS_CCR_Status_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define CCR_Status_0			(CCR_Status__0__PC)
#define CCR_Status_0_PS		(CCR_Status__0__PS)
#define CCR_Status_0_PC		(CCR_Status__0__PC)
#define CCR_Status_0_DR		(CCR_Status__0__DR)
#define CCR_Status_0_SHIFT	(CCR_Status__0__SHIFT)
#define CCR_Status_0_INTR	((uint16)((uint16)0x0003u << (CCR_Status__0__SHIFT*2u)))

#define CCR_Status_1			(CCR_Status__1__PC)
#define CCR_Status_1_PS		(CCR_Status__1__PS)
#define CCR_Status_1_PC		(CCR_Status__1__PC)
#define CCR_Status_1_DR		(CCR_Status__1__DR)
#define CCR_Status_1_SHIFT	(CCR_Status__1__SHIFT)
#define CCR_Status_1_INTR	((uint16)((uint16)0x0003u << (CCR_Status__1__SHIFT*2u)))

#define CCR_Status_2			(CCR_Status__2__PC)
#define CCR_Status_2_PS		(CCR_Status__2__PS)
#define CCR_Status_2_PC		(CCR_Status__2__PC)
#define CCR_Status_2_DR		(CCR_Status__2__DR)
#define CCR_Status_2_SHIFT	(CCR_Status__2__SHIFT)
#define CCR_Status_2_INTR	((uint16)((uint16)0x0003u << (CCR_Status__2__SHIFT*2u)))

#define CCR_Status_3			(CCR_Status__3__PC)
#define CCR_Status_3_PS		(CCR_Status__3__PS)
#define CCR_Status_3_PC		(CCR_Status__3__PC)
#define CCR_Status_3_DR		(CCR_Status__3__DR)
#define CCR_Status_3_SHIFT	(CCR_Status__3__SHIFT)
#define CCR_Status_3_INTR	((uint16)((uint16)0x0003u << (CCR_Status__3__SHIFT*2u)))

#define CCR_Status_INTR_ALL	 ((uint16)(CCR_Status_0_INTR| CCR_Status_1_INTR| CCR_Status_2_INTR| CCR_Status_3_INTR))


#endif /* End Pins CCR_Status_ALIASES_H */


/* [] END OF FILE */
