/*******************************************************************************
* File Name: Kontaktor.c  
* Version 2.20
*
* Description:
*  This file contains APIs to set up the Pins component for low power modes.
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "Kontaktor.h"

static Kontaktor_BACKUP_STRUCT  Kontaktor_backup = {0u, 0u, 0u};


/*******************************************************************************
* Function Name: Kontaktor_Sleep
****************************************************************************//**
*
* \brief Stores the pin configuration and prepares the pin for entering chip 
*  deep-sleep/hibernate modes. This function applies only to SIO and USBIO pins.
*  It should not be called for GPIO or GPIO_OVT pins.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None 
*  
* \sideeffect
*  For SIO pins, this function configures the pin input threshold to CMOS and
*  drive level to Vddio. This is needed for SIO pins when in device 
*  deep-sleep/hibernate modes.
*
* \funcusage
*  \snippet Kontaktor_SUT.c usage_Kontaktor_Sleep_Wakeup
*******************************************************************************/
void Kontaktor_Sleep(void)
{
    #if defined(Kontaktor__PC)
        Kontaktor_backup.pcState = Kontaktor_PC;
    #else
        #if (CY_PSOC4_4200L)
            /* Save the regulator state and put the PHY into suspend mode */
            Kontaktor_backup.usbState = Kontaktor_CR1_REG;
            Kontaktor_USB_POWER_REG |= Kontaktor_USBIO_ENTER_SLEEP;
            Kontaktor_CR1_REG &= Kontaktor_USBIO_CR1_OFF;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(Kontaktor__SIO)
        Kontaktor_backup.sioState = Kontaktor_SIO_REG;
        /* SIO requires unregulated output buffer and single ended input buffer */
        Kontaktor_SIO_REG &= (uint32)(~Kontaktor_SIO_LPM_MASK);
    #endif  
}


/*******************************************************************************
* Function Name: Kontaktor_Wakeup
****************************************************************************//**
*
* \brief Restores the pin configuration that was saved during Pin_Sleep(). This 
* function applies only to SIO and USBIO pins. It should not be called for
* GPIO or GPIO_OVT pins.
*
* For USBIO pins, the wakeup is only triggered for falling edge interrupts.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None
*  
* \funcusage
*  Refer to Kontaktor_Sleep() for an example usage.
*******************************************************************************/
void Kontaktor_Wakeup(void)
{
    #if defined(Kontaktor__PC)
        Kontaktor_PC = Kontaktor_backup.pcState;
    #else
        #if (CY_PSOC4_4200L)
            /* Restore the regulator state and come out of suspend mode */
            Kontaktor_USB_POWER_REG &= Kontaktor_USBIO_EXIT_SLEEP_PH1;
            Kontaktor_CR1_REG = Kontaktor_backup.usbState;
            Kontaktor_USB_POWER_REG &= Kontaktor_USBIO_EXIT_SLEEP_PH2;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(Kontaktor__SIO)
        Kontaktor_SIO_REG = Kontaktor_backup.sioState;
    #endif
}


/* [] END OF FILE */
