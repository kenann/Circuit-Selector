/*******************************************************************************
* File Name: Local_Control_On_Off_Uln.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Local_Control_On_Off_Uln_ALIASES_H) /* Pins Local_Control_On_Off_Uln_ALIASES_H */
#define CY_PINS_Local_Control_On_Off_Uln_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Local_Control_On_Off_Uln_0			(Local_Control_On_Off_Uln__0__PC)
#define Local_Control_On_Off_Uln_0_PS		(Local_Control_On_Off_Uln__0__PS)
#define Local_Control_On_Off_Uln_0_PC		(Local_Control_On_Off_Uln__0__PC)
#define Local_Control_On_Off_Uln_0_DR		(Local_Control_On_Off_Uln__0__DR)
#define Local_Control_On_Off_Uln_0_SHIFT	(Local_Control_On_Off_Uln__0__SHIFT)
#define Local_Control_On_Off_Uln_0_INTR	((uint16)((uint16)0x0003u << (Local_Control_On_Off_Uln__0__SHIFT*2u)))

#define Local_Control_On_Off_Uln_INTR_ALL	 ((uint16)(Local_Control_On_Off_Uln_0_INTR))


#endif /* End Pins Local_Control_On_Off_Uln_ALIASES_H */


/* [] END OF FILE */
