/*******************************************************************************
* File Name: Tower.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Tower_ALIASES_H) /* Pins Tower_ALIASES_H */
#define CY_PINS_Tower_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Tower_0			(Tower__0__PC)
#define Tower_0_PS		(Tower__0__PS)
#define Tower_0_PC		(Tower__0__PC)
#define Tower_0_DR		(Tower__0__DR)
#define Tower_0_SHIFT	(Tower__0__SHIFT)
#define Tower_0_INTR	((uint16)((uint16)0x0003u << (Tower__0__SHIFT*2u)))

#define Tower_1			(Tower__1__PC)
#define Tower_1_PS		(Tower__1__PS)
#define Tower_1_PC		(Tower__1__PC)
#define Tower_1_DR		(Tower__1__DR)
#define Tower_1_SHIFT	(Tower__1__SHIFT)
#define Tower_1_INTR	((uint16)((uint16)0x0003u << (Tower__1__SHIFT*2u)))

#define Tower_2			(Tower__2__PC)
#define Tower_2_PS		(Tower__2__PS)
#define Tower_2_PC		(Tower__2__PC)
#define Tower_2_DR		(Tower__2__DR)
#define Tower_2_SHIFT	(Tower__2__SHIFT)
#define Tower_2_INTR	((uint16)((uint16)0x0003u << (Tower__2__SHIFT*2u)))

#define Tower_3			(Tower__3__PC)
#define Tower_3_PS		(Tower__3__PS)
#define Tower_3_PC		(Tower__3__PC)
#define Tower_3_DR		(Tower__3__DR)
#define Tower_3_SHIFT	(Tower__3__SHIFT)
#define Tower_3_INTR	((uint16)((uint16)0x0003u << (Tower__3__SHIFT*2u)))

#define Tower_INTR_ALL	 ((uint16)(Tower_0_INTR| Tower_1_INTR| Tower_2_INTR| Tower_3_INTR))


#endif /* End Pins Tower_ALIASES_H */


/* [] END OF FILE */
