/*******************************************************************************
* File Name: CCR_Remote_Lamp_Uln.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CCR_Remote_Lamp_Uln_H) /* Pins CCR_Remote_Lamp_Uln_H */
#define CY_PINS_CCR_Remote_Lamp_Uln_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CCR_Remote_Lamp_Uln_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} CCR_Remote_Lamp_Uln_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   CCR_Remote_Lamp_Uln_Read(void);
void    CCR_Remote_Lamp_Uln_Write(uint8 value);
uint8   CCR_Remote_Lamp_Uln_ReadDataReg(void);
#if defined(CCR_Remote_Lamp_Uln__PC) || (CY_PSOC4_4200L) 
    void    CCR_Remote_Lamp_Uln_SetDriveMode(uint8 mode);
#endif
void    CCR_Remote_Lamp_Uln_SetInterruptMode(uint16 position, uint16 mode);
uint8   CCR_Remote_Lamp_Uln_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void CCR_Remote_Lamp_Uln_Sleep(void); 
void CCR_Remote_Lamp_Uln_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(CCR_Remote_Lamp_Uln__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define CCR_Remote_Lamp_Uln_DRIVE_MODE_BITS        (3)
    #define CCR_Remote_Lamp_Uln_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - CCR_Remote_Lamp_Uln_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the CCR_Remote_Lamp_Uln_SetDriveMode() function.
         *  @{
         */
        #define CCR_Remote_Lamp_Uln_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define CCR_Remote_Lamp_Uln_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define CCR_Remote_Lamp_Uln_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define CCR_Remote_Lamp_Uln_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define CCR_Remote_Lamp_Uln_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define CCR_Remote_Lamp_Uln_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define CCR_Remote_Lamp_Uln_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define CCR_Remote_Lamp_Uln_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define CCR_Remote_Lamp_Uln_MASK               CCR_Remote_Lamp_Uln__MASK
#define CCR_Remote_Lamp_Uln_SHIFT              CCR_Remote_Lamp_Uln__SHIFT
#define CCR_Remote_Lamp_Uln_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in CCR_Remote_Lamp_Uln_SetInterruptMode() function.
     *  @{
     */
        #define CCR_Remote_Lamp_Uln_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define CCR_Remote_Lamp_Uln_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define CCR_Remote_Lamp_Uln_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define CCR_Remote_Lamp_Uln_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(CCR_Remote_Lamp_Uln__SIO)
    #define CCR_Remote_Lamp_Uln_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(CCR_Remote_Lamp_Uln__PC) && (CY_PSOC4_4200L)
    #define CCR_Remote_Lamp_Uln_USBIO_ENABLE               ((uint32)0x80000000u)
    #define CCR_Remote_Lamp_Uln_USBIO_DISABLE              ((uint32)(~CCR_Remote_Lamp_Uln_USBIO_ENABLE))
    #define CCR_Remote_Lamp_Uln_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define CCR_Remote_Lamp_Uln_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define CCR_Remote_Lamp_Uln_USBIO_ENTER_SLEEP          ((uint32)((1u << CCR_Remote_Lamp_Uln_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << CCR_Remote_Lamp_Uln_USBIO_SUSPEND_DEL_SHIFT)))
    #define CCR_Remote_Lamp_Uln_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << CCR_Remote_Lamp_Uln_USBIO_SUSPEND_SHIFT)))
    #define CCR_Remote_Lamp_Uln_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << CCR_Remote_Lamp_Uln_USBIO_SUSPEND_DEL_SHIFT)))
    #define CCR_Remote_Lamp_Uln_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(CCR_Remote_Lamp_Uln__PC)
    /* Port Configuration */
    #define CCR_Remote_Lamp_Uln_PC                 (* (reg32 *) CCR_Remote_Lamp_Uln__PC)
#endif
/* Pin State */
#define CCR_Remote_Lamp_Uln_PS                     (* (reg32 *) CCR_Remote_Lamp_Uln__PS)
/* Data Register */
#define CCR_Remote_Lamp_Uln_DR                     (* (reg32 *) CCR_Remote_Lamp_Uln__DR)
/* Input Buffer Disable Override */
#define CCR_Remote_Lamp_Uln_INP_DIS                (* (reg32 *) CCR_Remote_Lamp_Uln__PC2)

/* Interrupt configuration Registers */
#define CCR_Remote_Lamp_Uln_INTCFG                 (* (reg32 *) CCR_Remote_Lamp_Uln__INTCFG)
#define CCR_Remote_Lamp_Uln_INTSTAT                (* (reg32 *) CCR_Remote_Lamp_Uln__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define CCR_Remote_Lamp_Uln_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(CCR_Remote_Lamp_Uln__SIO)
    #define CCR_Remote_Lamp_Uln_SIO_REG            (* (reg32 *) CCR_Remote_Lamp_Uln__SIO)
#endif /* (CCR_Remote_Lamp_Uln__SIO_CFG) */

/* USBIO registers */
#if !defined(CCR_Remote_Lamp_Uln__PC) && (CY_PSOC4_4200L)
    #define CCR_Remote_Lamp_Uln_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define CCR_Remote_Lamp_Uln_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define CCR_Remote_Lamp_Uln_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define CCR_Remote_Lamp_Uln_DRIVE_MODE_SHIFT       (0x00u)
#define CCR_Remote_Lamp_Uln_DRIVE_MODE_MASK        (0x07u << CCR_Remote_Lamp_Uln_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins CCR_Remote_Lamp_Uln_H */


/* [] END OF FILE */
