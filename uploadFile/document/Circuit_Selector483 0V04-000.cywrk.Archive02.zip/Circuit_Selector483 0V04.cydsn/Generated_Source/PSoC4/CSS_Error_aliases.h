/*******************************************************************************
* File Name: CSS_Error.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CSS_Error_ALIASES_H) /* Pins CSS_Error_ALIASES_H */
#define CY_PINS_CSS_Error_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define CSS_Error_0			(CSS_Error__0__PC)
#define CSS_Error_0_PS		(CSS_Error__0__PS)
#define CSS_Error_0_PC		(CSS_Error__0__PC)
#define CSS_Error_0_DR		(CSS_Error__0__DR)
#define CSS_Error_0_SHIFT	(CSS_Error__0__SHIFT)
#define CSS_Error_0_INTR	((uint16)((uint16)0x0003u << (CSS_Error__0__SHIFT*2u)))

#define CSS_Error_INTR_ALL	 ((uint16)(CSS_Error_0_INTR))


#endif /* End Pins CSS_Error_ALIASES_H */


/* [] END OF FILE */
