/*******************************************************************************
* File Name: Remote_Rotary_opto.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Remote_Rotary_opto_ALIASES_H) /* Pins Remote_Rotary_opto_ALIASES_H */
#define CY_PINS_Remote_Rotary_opto_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Remote_Rotary_opto_0			(Remote_Rotary_opto__0__PC)
#define Remote_Rotary_opto_0_PS		(Remote_Rotary_opto__0__PS)
#define Remote_Rotary_opto_0_PC		(Remote_Rotary_opto__0__PC)
#define Remote_Rotary_opto_0_DR		(Remote_Rotary_opto__0__DR)
#define Remote_Rotary_opto_0_SHIFT	(Remote_Rotary_opto__0__SHIFT)
#define Remote_Rotary_opto_0_INTR	((uint16)((uint16)0x0003u << (Remote_Rotary_opto__0__SHIFT*2u)))

#define Remote_Rotary_opto_INTR_ALL	 ((uint16)(Remote_Rotary_opto_0_INTR))


#endif /* End Pins Remote_Rotary_opto_ALIASES_H */


/* [] END OF FILE */
