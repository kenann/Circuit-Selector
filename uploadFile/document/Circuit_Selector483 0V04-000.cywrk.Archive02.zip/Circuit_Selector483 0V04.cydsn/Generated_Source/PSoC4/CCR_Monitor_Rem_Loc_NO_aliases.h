/*******************************************************************************
* File Name: CCR_Monitor_Rem_Loc_NO.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CCR_Monitor_Rem_Loc_NO_ALIASES_H) /* Pins CCR_Monitor_Rem_Loc_NO_ALIASES_H */
#define CY_PINS_CCR_Monitor_Rem_Loc_NO_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define CCR_Monitor_Rem_Loc_NO_0			(CCR_Monitor_Rem_Loc_NO__0__PC)
#define CCR_Monitor_Rem_Loc_NO_0_PS		(CCR_Monitor_Rem_Loc_NO__0__PS)
#define CCR_Monitor_Rem_Loc_NO_0_PC		(CCR_Monitor_Rem_Loc_NO__0__PC)
#define CCR_Monitor_Rem_Loc_NO_0_DR		(CCR_Monitor_Rem_Loc_NO__0__DR)
#define CCR_Monitor_Rem_Loc_NO_0_SHIFT	(CCR_Monitor_Rem_Loc_NO__0__SHIFT)
#define CCR_Monitor_Rem_Loc_NO_0_INTR	((uint16)((uint16)0x0003u << (CCR_Monitor_Rem_Loc_NO__0__SHIFT*2u)))

#define CCR_Monitor_Rem_Loc_NO_INTR_ALL	 ((uint16)(CCR_Monitor_Rem_Loc_NO_0_INTR))


#endif /* End Pins CCR_Monitor_Rem_Loc_NO_ALIASES_H */


/* [] END OF FILE */
