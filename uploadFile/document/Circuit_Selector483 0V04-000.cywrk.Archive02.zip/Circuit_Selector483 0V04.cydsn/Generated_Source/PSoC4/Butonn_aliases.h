/*******************************************************************************
* File Name: Butonn.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Butonn_ALIASES_H) /* Pins Butonn_ALIASES_H */
#define CY_PINS_Butonn_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Butonn_0			(Butonn__0__PC)
#define Butonn_0_PS		(Butonn__0__PS)
#define Butonn_0_PC		(Butonn__0__PC)
#define Butonn_0_DR		(Butonn__0__DR)
#define Butonn_0_SHIFT	(Butonn__0__SHIFT)
#define Butonn_0_INTR	((uint16)((uint16)0x0003u << (Butonn__0__SHIFT*2u)))

#define Butonn_1			(Butonn__1__PC)
#define Butonn_1_PS		(Butonn__1__PS)
#define Butonn_1_PC		(Butonn__1__PC)
#define Butonn_1_DR		(Butonn__1__DR)
#define Butonn_1_SHIFT	(Butonn__1__SHIFT)
#define Butonn_1_INTR	((uint16)((uint16)0x0003u << (Butonn__1__SHIFT*2u)))

#define Butonn_2			(Butonn__2__PC)
#define Butonn_2_PS		(Butonn__2__PS)
#define Butonn_2_PC		(Butonn__2__PC)
#define Butonn_2_DR		(Butonn__2__DR)
#define Butonn_2_SHIFT	(Butonn__2__SHIFT)
#define Butonn_2_INTR	((uint16)((uint16)0x0003u << (Butonn__2__SHIFT*2u)))

#define Butonn_3			(Butonn__3__PC)
#define Butonn_3_PS		(Butonn__3__PS)
#define Butonn_3_PC		(Butonn__3__PC)
#define Butonn_3_DR		(Butonn__3__DR)
#define Butonn_3_SHIFT	(Butonn__3__SHIFT)
#define Butonn_3_INTR	((uint16)((uint16)0x0003u << (Butonn__3__SHIFT*2u)))

#define Butonn_INTR_ALL	 ((uint16)(Butonn_0_INTR| Butonn_1_INTR| Butonn_2_INTR| Butonn_3_INTR))


#endif /* End Pins Butonn_ALIASES_H */


/* [] END OF FILE */
