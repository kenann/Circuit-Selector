/*******************************************************************************
* File Name: Local_Rotary_opto.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Local_Rotary_opto_ALIASES_H) /* Pins Local_Rotary_opto_ALIASES_H */
#define CY_PINS_Local_Rotary_opto_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Local_Rotary_opto_0			(Local_Rotary_opto__0__PC)
#define Local_Rotary_opto_0_PS		(Local_Rotary_opto__0__PS)
#define Local_Rotary_opto_0_PC		(Local_Rotary_opto__0__PC)
#define Local_Rotary_opto_0_DR		(Local_Rotary_opto__0__DR)
#define Local_Rotary_opto_0_SHIFT	(Local_Rotary_opto__0__SHIFT)
#define Local_Rotary_opto_0_INTR	((uint16)((uint16)0x0003u << (Local_Rotary_opto__0__SHIFT*2u)))

#define Local_Rotary_opto_INTR_ALL	 ((uint16)(Local_Rotary_opto_0_INTR))


#endif /* End Pins Local_Rotary_opto_ALIASES_H */


/* [] END OF FILE */
