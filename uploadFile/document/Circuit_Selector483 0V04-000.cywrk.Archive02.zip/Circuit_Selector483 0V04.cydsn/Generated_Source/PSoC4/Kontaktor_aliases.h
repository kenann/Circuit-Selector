/*******************************************************************************
* File Name: Kontaktor.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Kontaktor_ALIASES_H) /* Pins Kontaktor_ALIASES_H */
#define CY_PINS_Kontaktor_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Kontaktor_0			(Kontaktor__0__PC)
#define Kontaktor_0_PS		(Kontaktor__0__PS)
#define Kontaktor_0_PC		(Kontaktor__0__PC)
#define Kontaktor_0_DR		(Kontaktor__0__DR)
#define Kontaktor_0_SHIFT	(Kontaktor__0__SHIFT)
#define Kontaktor_0_INTR	((uint16)((uint16)0x0003u << (Kontaktor__0__SHIFT*2u)))

#define Kontaktor_1			(Kontaktor__1__PC)
#define Kontaktor_1_PS		(Kontaktor__1__PS)
#define Kontaktor_1_PC		(Kontaktor__1__PC)
#define Kontaktor_1_DR		(Kontaktor__1__DR)
#define Kontaktor_1_SHIFT	(Kontaktor__1__SHIFT)
#define Kontaktor_1_INTR	((uint16)((uint16)0x0003u << (Kontaktor__1__SHIFT*2u)))

#define Kontaktor_2			(Kontaktor__2__PC)
#define Kontaktor_2_PS		(Kontaktor__2__PS)
#define Kontaktor_2_PC		(Kontaktor__2__PC)
#define Kontaktor_2_DR		(Kontaktor__2__DR)
#define Kontaktor_2_SHIFT	(Kontaktor__2__SHIFT)
#define Kontaktor_2_INTR	((uint16)((uint16)0x0003u << (Kontaktor__2__SHIFT*2u)))

#define Kontaktor_3			(Kontaktor__3__PC)
#define Kontaktor_3_PS		(Kontaktor__3__PS)
#define Kontaktor_3_PC		(Kontaktor__3__PC)
#define Kontaktor_3_DR		(Kontaktor__3__DR)
#define Kontaktor_3_SHIFT	(Kontaktor__3__SHIFT)
#define Kontaktor_3_INTR	((uint16)((uint16)0x0003u << (Kontaktor__3__SHIFT*2u)))

#define Kontaktor_INTR_ALL	 ((uint16)(Kontaktor_0_INTR| Kontaktor_1_INTR| Kontaktor_2_INTR| Kontaktor_3_INTR))


#endif /* End Pins Kontaktor_ALIASES_H */


/* [] END OF FILE */
