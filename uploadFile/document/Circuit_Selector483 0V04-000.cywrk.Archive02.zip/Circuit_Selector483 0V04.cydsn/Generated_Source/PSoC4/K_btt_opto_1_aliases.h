/*******************************************************************************
* File Name: K_btt_opto_1.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_K_btt_opto_1_ALIASES_H) /* Pins K_btt_opto_1_ALIASES_H */
#define CY_PINS_K_btt_opto_1_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define K_btt_opto_1_0			(K_btt_opto_1__0__PC)
#define K_btt_opto_1_0_PS		(K_btt_opto_1__0__PS)
#define K_btt_opto_1_0_PC		(K_btt_opto_1__0__PC)
#define K_btt_opto_1_0_DR		(K_btt_opto_1__0__DR)
#define K_btt_opto_1_0_SHIFT	(K_btt_opto_1__0__SHIFT)
#define K_btt_opto_1_0_INTR	((uint16)((uint16)0x0003u << (K_btt_opto_1__0__SHIFT*2u)))

#define K_btt_opto_1_1			(K_btt_opto_1__1__PC)
#define K_btt_opto_1_1_PS		(K_btt_opto_1__1__PS)
#define K_btt_opto_1_1_PC		(K_btt_opto_1__1__PC)
#define K_btt_opto_1_1_DR		(K_btt_opto_1__1__DR)
#define K_btt_opto_1_1_SHIFT	(K_btt_opto_1__1__SHIFT)
#define K_btt_opto_1_1_INTR	((uint16)((uint16)0x0003u << (K_btt_opto_1__1__SHIFT*2u)))

#define K_btt_opto_1_2			(K_btt_opto_1__2__PC)
#define K_btt_opto_1_2_PS		(K_btt_opto_1__2__PS)
#define K_btt_opto_1_2_PC		(K_btt_opto_1__2__PC)
#define K_btt_opto_1_2_DR		(K_btt_opto_1__2__DR)
#define K_btt_opto_1_2_SHIFT	(K_btt_opto_1__2__SHIFT)
#define K_btt_opto_1_2_INTR	((uint16)((uint16)0x0003u << (K_btt_opto_1__2__SHIFT*2u)))

#define K_btt_opto_1_3			(K_btt_opto_1__3__PC)
#define K_btt_opto_1_3_PS		(K_btt_opto_1__3__PS)
#define K_btt_opto_1_3_PC		(K_btt_opto_1__3__PC)
#define K_btt_opto_1_3_DR		(K_btt_opto_1__3__DR)
#define K_btt_opto_1_3_SHIFT	(K_btt_opto_1__3__SHIFT)
#define K_btt_opto_1_3_INTR	((uint16)((uint16)0x0003u << (K_btt_opto_1__3__SHIFT*2u)))

#define K_btt_opto_1_INTR_ALL	 ((uint16)(K_btt_opto_1_0_INTR| K_btt_opto_1_1_INTR| K_btt_opto_1_2_INTR| K_btt_opto_1_3_INTR))


#endif /* End Pins K_btt_opto_1_ALIASES_H */


/* [] END OF FILE */
