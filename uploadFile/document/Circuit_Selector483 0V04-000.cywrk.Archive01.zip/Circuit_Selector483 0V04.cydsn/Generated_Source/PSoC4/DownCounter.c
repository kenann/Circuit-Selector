/*******************************************************************************
* File Name: DownCounter.c  
* Version 3.0
*
*  Description:
*     The Counter component consists of a 8, 16, 24 or 32-bit counter with
*     a selectable period between 2 and 2^Width - 1.  
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "DownCounter.h"

uint8 DownCounter_initVar = 0u;


/*******************************************************************************
* Function Name: DownCounter_Init
********************************************************************************
* Summary:
*     Initialize to the schematic state
* 
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void DownCounter_Init(void) 
{
        #if (!DownCounter_UsingFixedFunction && !DownCounter_ControlRegRemoved)
            uint8 ctrl;
        #endif /* (!DownCounter_UsingFixedFunction && !DownCounter_ControlRegRemoved) */
        
        #if(!DownCounter_UsingFixedFunction) 
            /* Interrupt State Backup for Critical Region*/
            uint8 DownCounter_interruptState;
        #endif /* (!DownCounter_UsingFixedFunction) */
        
        #if (DownCounter_UsingFixedFunction)
            /* Clear all bits but the enable bit (if it's already set for Timer operation */
            DownCounter_CONTROL &= DownCounter_CTRL_ENABLE;
            
            /* Clear the mode bits for continuous run mode */
            #if (CY_PSOC5A)
                DownCounter_CONTROL2 &= ((uint8)(~DownCounter_CTRL_MODE_MASK));
            #endif /* (CY_PSOC5A) */
            #if (CY_PSOC3 || CY_PSOC5LP)
                DownCounter_CONTROL3 &= ((uint8)(~DownCounter_CTRL_MODE_MASK));                
            #endif /* (CY_PSOC3 || CY_PSOC5LP) */
            /* Check if One Shot mode is enabled i.e. RunMode !=0*/
            #if (DownCounter_RunModeUsed != 0x0u)
                /* Set 3rd bit of Control register to enable one shot mode */
                DownCounter_CONTROL |= DownCounter_ONESHOT;
            #endif /* (DownCounter_RunModeUsed != 0x0u) */
            
            /* Set the IRQ to use the status register interrupts */
            DownCounter_CONTROL2 |= DownCounter_CTRL2_IRQ_SEL;
            
            /* Clear and Set SYNCTC and SYNCCMP bits of RT1 register */
            DownCounter_RT1 &= ((uint8)(~DownCounter_RT1_MASK));
            DownCounter_RT1 |= DownCounter_SYNC;     
                    
            /*Enable DSI Sync all all inputs of the Timer*/
            DownCounter_RT1 &= ((uint8)(~DownCounter_SYNCDSI_MASK));
            DownCounter_RT1 |= DownCounter_SYNCDSI_EN;

        #else
            #if(!DownCounter_ControlRegRemoved)
            /* Set the default compare mode defined in the parameter */
            ctrl = DownCounter_CONTROL & ((uint8)(~DownCounter_CTRL_CMPMODE_MASK));
            DownCounter_CONTROL = ctrl | DownCounter_DEFAULT_COMPARE_MODE;
            
            /* Set the default capture mode defined in the parameter */
            ctrl = DownCounter_CONTROL & ((uint8)(~DownCounter_CTRL_CAPMODE_MASK));
            
            #if( 0 != DownCounter_CAPTURE_MODE_CONF)
                DownCounter_CONTROL = ctrl | DownCounter_DEFAULT_CAPTURE_MODE;
            #else
                DownCounter_CONTROL = ctrl;
            #endif /* 0 != DownCounter_CAPTURE_MODE */ 
            
            #endif /* (!DownCounter_ControlRegRemoved) */
        #endif /* (DownCounter_UsingFixedFunction) */
        
        /* Clear all data in the FIFO's */
        #if (!DownCounter_UsingFixedFunction)
            DownCounter_ClearFIFO();
        #endif /* (!DownCounter_UsingFixedFunction) */
        
        /* Set Initial values from Configuration */
        DownCounter_WritePeriod(DownCounter_INIT_PERIOD_VALUE);
        #if (!(DownCounter_UsingFixedFunction && (CY_PSOC5A)))
            DownCounter_WriteCounter(DownCounter_INIT_COUNTER_VALUE);
        #endif /* (!(DownCounter_UsingFixedFunction && (CY_PSOC5A))) */
        DownCounter_SetInterruptMode(DownCounter_INIT_INTERRUPTS_MASK);
        
        #if (!DownCounter_UsingFixedFunction)
            /* Read the status register to clear the unwanted interrupts */
            (void)DownCounter_ReadStatusRegister();
            /* Set the compare value (only available to non-fixed function implementation */
            DownCounter_WriteCompare(DownCounter_INIT_COMPARE_VALUE);
            /* Use the interrupt output of the status register for IRQ output */
            
            /* CyEnterCriticalRegion and CyExitCriticalRegion are used to mark following region critical*/
            /* Enter Critical Region*/
            DownCounter_interruptState = CyEnterCriticalSection();
            
            DownCounter_STATUS_AUX_CTRL |= DownCounter_STATUS_ACTL_INT_EN_MASK;
            
            /* Exit Critical Region*/
            CyExitCriticalSection(DownCounter_interruptState);
            
        #endif /* (!DownCounter_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: DownCounter_Enable
********************************************************************************
* Summary:
*     Enable the Counter
* 
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Side Effects: 
*   If the Enable mode is set to Hardware only then this function has no effect 
*   on the operation of the counter.
*
*******************************************************************************/
void DownCounter_Enable(void) 
{
    /* Globally Enable the Fixed Function Block chosen */
    #if (DownCounter_UsingFixedFunction)
        DownCounter_GLOBAL_ENABLE |= DownCounter_BLOCK_EN_MASK;
        DownCounter_GLOBAL_STBY_ENABLE |= DownCounter_BLOCK_STBY_EN_MASK;
    #endif /* (DownCounter_UsingFixedFunction) */  
        
    /* Enable the counter from the control register  */
    /* If Fixed Function then make sure Mode is set correctly */
    /* else make sure reset is clear */
    #if(!DownCounter_ControlRegRemoved || DownCounter_UsingFixedFunction)
        DownCounter_CONTROL |= DownCounter_CTRL_ENABLE;                
    #endif /* (!DownCounter_ControlRegRemoved || DownCounter_UsingFixedFunction) */
    
}


/*******************************************************************************
* Function Name: DownCounter_Start
********************************************************************************
* Summary:
*  Enables the counter for operation 
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Global variables:
*  DownCounter_initVar: Is modified when this function is called for the  
*   first time. Is used to ensure that initialization happens only once.
*
*******************************************************************************/
void DownCounter_Start(void) 
{
    if(DownCounter_initVar == 0u)
    {
        DownCounter_Init();
        
        DownCounter_initVar = 1u; /* Clear this bit for Initialization */        
    }
    
    /* Enable the Counter */
    DownCounter_Enable();        
}


/*******************************************************************************
* Function Name: DownCounter_Stop
********************************************************************************
* Summary:
* Halts the counter, but does not change any modes or disable interrupts.
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Side Effects: If the Enable mode is set to Hardware only then this function
*               has no effect on the operation of the counter.
*
*******************************************************************************/
void DownCounter_Stop(void) 
{
    /* Disable Counter */
    #if(!DownCounter_ControlRegRemoved || DownCounter_UsingFixedFunction)
        DownCounter_CONTROL &= ((uint8)(~DownCounter_CTRL_ENABLE));        
    #endif /* (!DownCounter_ControlRegRemoved || DownCounter_UsingFixedFunction) */
    
    /* Globally disable the Fixed Function Block chosen */
    #if (DownCounter_UsingFixedFunction)
        DownCounter_GLOBAL_ENABLE &= ((uint8)(~DownCounter_BLOCK_EN_MASK));
        DownCounter_GLOBAL_STBY_ENABLE &= ((uint8)(~DownCounter_BLOCK_STBY_EN_MASK));
    #endif /* (DownCounter_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: DownCounter_SetInterruptMode
********************************************************************************
* Summary:
* Configures which interrupt sources are enabled to generate the final interrupt
*
* Parameters:  
*  InterruptsMask: This parameter is an or'd collection of the status bits
*                   which will be allowed to generate the counters interrupt.   
*
* Return: 
*  void
*
*******************************************************************************/
void DownCounter_SetInterruptMode(uint8 interruptsMask) 
{
    DownCounter_STATUS_MASK = interruptsMask;
}


/*******************************************************************************
* Function Name: DownCounter_ReadStatusRegister
********************************************************************************
* Summary:
*   Reads the status register and returns it's state. This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the status register
*
* Side Effects:
*   Status register bits may be clear on read. 
*
*******************************************************************************/
uint8   DownCounter_ReadStatusRegister(void) 
{
    return DownCounter_STATUS;
}


#if(!DownCounter_ControlRegRemoved)
/*******************************************************************************
* Function Name: DownCounter_ReadControlRegister
********************************************************************************
* Summary:
*   Reads the control register and returns it's state. This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the control register
*
*******************************************************************************/
uint8   DownCounter_ReadControlRegister(void) 
{
    return DownCounter_CONTROL;
}


/*******************************************************************************
* Function Name: DownCounter_WriteControlRegister
********************************************************************************
* Summary:
*   Sets the bit-field of the control register.  This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the control register
*
*******************************************************************************/
void    DownCounter_WriteControlRegister(uint8 control) 
{
    DownCounter_CONTROL = control;
}

#endif  /* (!DownCounter_ControlRegRemoved) */


#if (!(DownCounter_UsingFixedFunction && (CY_PSOC5A)))
/*******************************************************************************
* Function Name: DownCounter_WriteCounter
********************************************************************************
* Summary:
*   This funtion is used to set the counter to a specific value
*
* Parameters:  
*  counter:  New counter value. 
*
* Return: 
*  void 
*
*******************************************************************************/
void DownCounter_WriteCounter(uint16 counter) \
                                   
{
    #if(DownCounter_UsingFixedFunction)
        /* assert if block is already enabled */
        CYASSERT (0u == (DownCounter_GLOBAL_ENABLE & DownCounter_BLOCK_EN_MASK));
        /* If block is disabled, enable it and then write the counter */
        DownCounter_GLOBAL_ENABLE |= DownCounter_BLOCK_EN_MASK;
        CY_SET_REG16(DownCounter_COUNTER_LSB_PTR, (uint16)counter);
        DownCounter_GLOBAL_ENABLE &= ((uint8)(~DownCounter_BLOCK_EN_MASK));
    #else
        CY_SET_REG16(DownCounter_COUNTER_LSB_PTR, counter);
    #endif /* (DownCounter_UsingFixedFunction) */
}
#endif /* (!(DownCounter_UsingFixedFunction && (CY_PSOC5A))) */


/*******************************************************************************
* Function Name: DownCounter_ReadCounter
********************************************************************************
* Summary:
* Returns the current value of the counter.  It doesn't matter
* if the counter is enabled or running.
*
* Parameters:  
*  void:  
*
* Return: 
*  (uint16) The present value of the counter.
*
*******************************************************************************/
uint16 DownCounter_ReadCounter(void) 
{
    /* Force capture by reading Accumulator */
    /* Must first do a software capture to be able to read the counter */
    /* It is up to the user code to make sure there isn't already captured data in the FIFO */
    #if(DownCounter_UsingFixedFunction)
		(void)CY_GET_REG16(DownCounter_COUNTER_LSB_PTR);
	#else
		(void)CY_GET_REG8(DownCounter_COUNTER_LSB_PTR_8BIT);
	#endif/* (DownCounter_UsingFixedFunction) */
    
    /* Read the data from the FIFO (or capture register for Fixed Function)*/
    #if(DownCounter_UsingFixedFunction)
        return ((uint16)CY_GET_REG16(DownCounter_STATICCOUNT_LSB_PTR));
    #else
        return (CY_GET_REG16(DownCounter_STATICCOUNT_LSB_PTR));
    #endif /* (DownCounter_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: DownCounter_ReadCapture
********************************************************************************
* Summary:
*   This function returns the last value captured.
*
* Parameters:  
*  void
*
* Return: 
*  (uint16) Present Capture value.
*
*******************************************************************************/
uint16 DownCounter_ReadCapture(void) 
{
    #if(DownCounter_UsingFixedFunction)
        return ((uint16)CY_GET_REG16(DownCounter_STATICCOUNT_LSB_PTR));
    #else
        return (CY_GET_REG16(DownCounter_STATICCOUNT_LSB_PTR));
    #endif /* (DownCounter_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: DownCounter_WritePeriod
********************************************************************************
* Summary:
* Changes the period of the counter.  The new period 
* will be loaded the next time terminal count is detected.
*
* Parameters:  
*  period: (uint16) A value of 0 will result in
*         the counter remaining at zero.  
*
* Return: 
*  void
*
*******************************************************************************/
void DownCounter_WritePeriod(uint16 period) 
{
    #if(DownCounter_UsingFixedFunction)
        CY_SET_REG16(DownCounter_PERIOD_LSB_PTR,(uint16)period);
    #else
        CY_SET_REG16(DownCounter_PERIOD_LSB_PTR, period);
    #endif /* (DownCounter_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: DownCounter_ReadPeriod
********************************************************************************
* Summary:
* Reads the current period value without affecting counter operation.
*
* Parameters:  
*  void:  
*
* Return: 
*  (uint16) Present period value.
*
*******************************************************************************/
uint16 DownCounter_ReadPeriod(void) 
{
    #if(DownCounter_UsingFixedFunction)
        return ((uint16)CY_GET_REG16(DownCounter_PERIOD_LSB_PTR));
    #else
        return (CY_GET_REG16(DownCounter_PERIOD_LSB_PTR));
    #endif /* (DownCounter_UsingFixedFunction) */
}


#if (!DownCounter_UsingFixedFunction)
/*******************************************************************************
* Function Name: DownCounter_WriteCompare
********************************************************************************
* Summary:
* Changes the compare value.  The compare output will 
* reflect the new value on the next UDB clock.  The compare output will be 
* driven high when the present counter value compares true based on the 
* configured compare mode setting. 
*
* Parameters:  
*  Compare:  New compare value. 
*
* Return: 
*  void
*
*******************************************************************************/
void DownCounter_WriteCompare(uint16 compare) \
                                   
{
    #if(DownCounter_UsingFixedFunction)
        CY_SET_REG16(DownCounter_COMPARE_LSB_PTR, (uint16)compare);
    #else
        CY_SET_REG16(DownCounter_COMPARE_LSB_PTR, compare);
    #endif /* (DownCounter_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: DownCounter_ReadCompare
********************************************************************************
* Summary:
* Returns the compare value.
*
* Parameters:  
*  void:
*
* Return: 
*  (uint16) Present compare value.
*
*******************************************************************************/
uint16 DownCounter_ReadCompare(void) 
{
    return (CY_GET_REG16(DownCounter_COMPARE_LSB_PTR));
}


#if (DownCounter_COMPARE_MODE_SOFTWARE)
/*******************************************************************************
* Function Name: DownCounter_SetCompareMode
********************************************************************************
* Summary:
*  Sets the software controlled Compare Mode.
*
* Parameters:
*  compareMode:  Compare Mode Enumerated Type.
*
* Return:
*  void
*
*******************************************************************************/
void DownCounter_SetCompareMode(uint8 compareMode) 
{
    /* Clear the compare mode bits in the control register */
    DownCounter_CONTROL &= ((uint8)(~DownCounter_CTRL_CMPMODE_MASK));
    
    /* Write the new setting */
    DownCounter_CONTROL |= compareMode;
}
#endif  /* (DownCounter_COMPARE_MODE_SOFTWARE) */


#if (DownCounter_CAPTURE_MODE_SOFTWARE)
/*******************************************************************************
* Function Name: DownCounter_SetCaptureMode
********************************************************************************
* Summary:
*  Sets the software controlled Capture Mode.
*
* Parameters:
*  captureMode:  Capture Mode Enumerated Type.
*
* Return:
*  void
*
*******************************************************************************/
void DownCounter_SetCaptureMode(uint8 captureMode) 
{
    /* Clear the capture mode bits in the control register */
    DownCounter_CONTROL &= ((uint8)(~DownCounter_CTRL_CAPMODE_MASK));
    
    /* Write the new setting */
    DownCounter_CONTROL |= ((uint8)((uint8)captureMode << DownCounter_CTRL_CAPMODE0_SHIFT));
}
#endif  /* (DownCounter_CAPTURE_MODE_SOFTWARE) */


/*******************************************************************************
* Function Name: DownCounter_ClearFIFO
********************************************************************************
* Summary:
*   This function clears all capture data from the capture FIFO
*
* Parameters:  
*  void:
*
* Return: 
*  None
*
*******************************************************************************/
void DownCounter_ClearFIFO(void) 
{

    while(0u != (DownCounter_ReadStatusRegister() & DownCounter_STATUS_FIFONEMP))
    {
        (void)DownCounter_ReadCapture();
    }

}
#endif  /* (!DownCounter_UsingFixedFunction) */


/* [] END OF FILE */

