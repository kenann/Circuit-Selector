/*******************************************************************************
* File Name: Buton.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Buton_ALIASES_H) /* Pins Buton_ALIASES_H */
#define CY_PINS_Buton_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Buton_0			(Buton__0__PC)
#define Buton_0_PS		(Buton__0__PS)
#define Buton_0_PC		(Buton__0__PC)
#define Buton_0_DR		(Buton__0__DR)
#define Buton_0_SHIFT	(Buton__0__SHIFT)
#define Buton_0_INTR	((uint16)((uint16)0x0003u << (Buton__0__SHIFT*2u)))

#define Buton_1			(Buton__1__PC)
#define Buton_1_PS		(Buton__1__PS)
#define Buton_1_PC		(Buton__1__PC)
#define Buton_1_DR		(Buton__1__DR)
#define Buton_1_SHIFT	(Buton__1__SHIFT)
#define Buton_1_INTR	((uint16)((uint16)0x0003u << (Buton__1__SHIFT*2u)))

#define Buton_2			(Buton__2__PC)
#define Buton_2_PS		(Buton__2__PS)
#define Buton_2_PC		(Buton__2__PC)
#define Buton_2_DR		(Buton__2__DR)
#define Buton_2_SHIFT	(Buton__2__SHIFT)
#define Buton_2_INTR	((uint16)((uint16)0x0003u << (Buton__2__SHIFT*2u)))

#define Buton_3			(Buton__3__PC)
#define Buton_3_PS		(Buton__3__PS)
#define Buton_3_PC		(Buton__3__PC)
#define Buton_3_DR		(Buton__3__DR)
#define Buton_3_SHIFT	(Buton__3__SHIFT)
#define Buton_3_INTR	((uint16)((uint16)0x0003u << (Buton__3__SHIFT*2u)))

#define Buton_INTR_ALL	 ((uint16)(Buton_0_INTR| Buton_1_INTR| Buton_2_INTR| Buton_3_INTR))


#endif /* End Pins Buton_ALIASES_H */


/* [] END OF FILE */
