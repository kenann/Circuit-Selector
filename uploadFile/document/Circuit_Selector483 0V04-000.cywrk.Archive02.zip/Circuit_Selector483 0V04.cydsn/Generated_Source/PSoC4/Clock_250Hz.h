/*******************************************************************************
* File Name: Clock_250Hz.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_Clock_250Hz_H)
#define CY_CLOCK_Clock_250Hz_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/
#if defined CYREG_PERI_DIV_CMD

void Clock_250Hz_StartEx(uint32 alignClkDiv);
#define Clock_250Hz_Start() \
    Clock_250Hz_StartEx(Clock_250Hz__PA_DIV_ID)

#else

void Clock_250Hz_Start(void);

#endif/* CYREG_PERI_DIV_CMD */

void Clock_250Hz_Stop(void);

void Clock_250Hz_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 Clock_250Hz_GetDividerRegister(void);
uint8  Clock_250Hz_GetFractionalDividerRegister(void);

#define Clock_250Hz_Enable()                         Clock_250Hz_Start()
#define Clock_250Hz_Disable()                        Clock_250Hz_Stop()
#define Clock_250Hz_SetDividerRegister(clkDivider, reset)  \
    Clock_250Hz_SetFractionalDividerRegister((clkDivider), 0u)
#define Clock_250Hz_SetDivider(clkDivider)           Clock_250Hz_SetDividerRegister((clkDivider), 1u)
#define Clock_250Hz_SetDividerValue(clkDivider)      Clock_250Hz_SetDividerRegister((clkDivider) - 1u, 1u)


/***************************************
*             Registers
***************************************/
#if defined CYREG_PERI_DIV_CMD

#define Clock_250Hz_DIV_ID     Clock_250Hz__DIV_ID

#define Clock_250Hz_CMD_REG    (*(reg32 *)CYREG_PERI_DIV_CMD)
#define Clock_250Hz_CTRL_REG   (*(reg32 *)Clock_250Hz__CTRL_REGISTER)
#define Clock_250Hz_DIV_REG    (*(reg32 *)Clock_250Hz__DIV_REGISTER)

#define Clock_250Hz_CMD_DIV_SHIFT          (0u)
#define Clock_250Hz_CMD_PA_DIV_SHIFT       (8u)
#define Clock_250Hz_CMD_DISABLE_SHIFT      (30u)
#define Clock_250Hz_CMD_ENABLE_SHIFT       (31u)

#define Clock_250Hz_CMD_DISABLE_MASK       ((uint32)((uint32)1u << Clock_250Hz_CMD_DISABLE_SHIFT))
#define Clock_250Hz_CMD_ENABLE_MASK        ((uint32)((uint32)1u << Clock_250Hz_CMD_ENABLE_SHIFT))

#define Clock_250Hz_DIV_FRAC_MASK  (0x000000F8u)
#define Clock_250Hz_DIV_FRAC_SHIFT (3u)
#define Clock_250Hz_DIV_INT_MASK   (0xFFFFFF00u)
#define Clock_250Hz_DIV_INT_SHIFT  (8u)

#else 

#define Clock_250Hz_DIV_REG        (*(reg32 *)Clock_250Hz__REGISTER)
#define Clock_250Hz_ENABLE_REG     Clock_250Hz_DIV_REG
#define Clock_250Hz_DIV_FRAC_MASK  Clock_250Hz__FRAC_MASK
#define Clock_250Hz_DIV_FRAC_SHIFT (16u)
#define Clock_250Hz_DIV_INT_MASK   Clock_250Hz__DIVIDER_MASK
#define Clock_250Hz_DIV_INT_SHIFT  (0u)

#endif/* CYREG_PERI_DIV_CMD */

#endif /* !defined(CY_CLOCK_Clock_250Hz_H) */

/* [] END OF FILE */
