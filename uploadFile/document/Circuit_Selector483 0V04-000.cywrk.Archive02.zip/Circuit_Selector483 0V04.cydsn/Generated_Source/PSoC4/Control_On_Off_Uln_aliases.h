/*******************************************************************************
* File Name: Control_On_Off_Uln.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Control_On_Off_Uln_ALIASES_H) /* Pins Control_On_Off_Uln_ALIASES_H */
#define CY_PINS_Control_On_Off_Uln_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Control_On_Off_Uln_0			(Control_On_Off_Uln__0__PC)
#define Control_On_Off_Uln_0_PS		(Control_On_Off_Uln__0__PS)
#define Control_On_Off_Uln_0_PC		(Control_On_Off_Uln__0__PC)
#define Control_On_Off_Uln_0_DR		(Control_On_Off_Uln__0__DR)
#define Control_On_Off_Uln_0_SHIFT	(Control_On_Off_Uln__0__SHIFT)
#define Control_On_Off_Uln_0_INTR	((uint16)((uint16)0x0003u << (Control_On_Off_Uln__0__SHIFT*2u)))

#define Control_On_Off_Uln_INTR_ALL	 ((uint16)(Control_On_Off_Uln_0_INTR))


#endif /* End Pins Control_On_Off_Uln_ALIASES_H */


/* [] END OF FILE */
