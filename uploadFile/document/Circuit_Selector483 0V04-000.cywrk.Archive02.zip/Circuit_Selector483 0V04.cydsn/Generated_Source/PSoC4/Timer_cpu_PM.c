/*******************************************************************************
* File Name: Timer_cpu_PM.c
* Version 2.80
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "Timer_cpu.h"

static Timer_cpu_backupStruct Timer_cpu_backup;


/*******************************************************************************
* Function Name: Timer_cpu_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_cpu_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Timer_cpu_SaveConfig(void) 
{
    #if (!Timer_cpu_UsingFixedFunction)
        Timer_cpu_backup.TimerUdb = Timer_cpu_ReadCounter();
        Timer_cpu_backup.InterruptMaskValue = Timer_cpu_STATUS_MASK;
        #if (Timer_cpu_UsingHWCaptureCounter)
            Timer_cpu_backup.TimerCaptureCounter = Timer_cpu_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!Timer_cpu_UDB_CONTROL_REG_REMOVED)
            Timer_cpu_backup.TimerControlRegister = Timer_cpu_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: Timer_cpu_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_cpu_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_cpu_RestoreConfig(void) 
{   
    #if (!Timer_cpu_UsingFixedFunction)

        Timer_cpu_WriteCounter(Timer_cpu_backup.TimerUdb);
        Timer_cpu_STATUS_MASK =Timer_cpu_backup.InterruptMaskValue;
        #if (Timer_cpu_UsingHWCaptureCounter)
            Timer_cpu_SetCaptureCount(Timer_cpu_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!Timer_cpu_UDB_CONTROL_REG_REMOVED)
            Timer_cpu_WriteControlRegister(Timer_cpu_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: Timer_cpu_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_cpu_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void Timer_cpu_Sleep(void) 
{
    #if(!Timer_cpu_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(Timer_cpu_CTRL_ENABLE == (Timer_cpu_CONTROL & Timer_cpu_CTRL_ENABLE))
        {
            /* Timer is enabled */
            Timer_cpu_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            Timer_cpu_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    Timer_cpu_Stop();
    Timer_cpu_SaveConfig();
}


/*******************************************************************************
* Function Name: Timer_cpu_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_cpu_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_cpu_Wakeup(void) 
{
    Timer_cpu_RestoreConfig();
    #if(!Timer_cpu_UDB_CONTROL_REG_REMOVED)
        if(Timer_cpu_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                Timer_cpu_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
