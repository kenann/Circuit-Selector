/*******************************************************************************
* File Name: ButtonPano.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_ButtonPano_ALIASES_H) /* Pins ButtonPano_ALIASES_H */
#define CY_PINS_ButtonPano_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define ButtonPano_0			(ButtonPano__0__PC)
#define ButtonPano_0_PS		(ButtonPano__0__PS)
#define ButtonPano_0_PC		(ButtonPano__0__PC)
#define ButtonPano_0_DR		(ButtonPano__0__DR)
#define ButtonPano_0_SHIFT	(ButtonPano__0__SHIFT)
#define ButtonPano_0_INTR	((uint16)((uint16)0x0003u << (ButtonPano__0__SHIFT*2u)))

#define ButtonPano_1			(ButtonPano__1__PC)
#define ButtonPano_1_PS		(ButtonPano__1__PS)
#define ButtonPano_1_PC		(ButtonPano__1__PC)
#define ButtonPano_1_DR		(ButtonPano__1__DR)
#define ButtonPano_1_SHIFT	(ButtonPano__1__SHIFT)
#define ButtonPano_1_INTR	((uint16)((uint16)0x0003u << (ButtonPano__1__SHIFT*2u)))

#define ButtonPano_2			(ButtonPano__2__PC)
#define ButtonPano_2_PS		(ButtonPano__2__PS)
#define ButtonPano_2_PC		(ButtonPano__2__PC)
#define ButtonPano_2_DR		(ButtonPano__2__DR)
#define ButtonPano_2_SHIFT	(ButtonPano__2__SHIFT)
#define ButtonPano_2_INTR	((uint16)((uint16)0x0003u << (ButtonPano__2__SHIFT*2u)))

#define ButtonPano_3			(ButtonPano__3__PC)
#define ButtonPano_3_PS		(ButtonPano__3__PS)
#define ButtonPano_3_PC		(ButtonPano__3__PC)
#define ButtonPano_3_DR		(ButtonPano__3__DR)
#define ButtonPano_3_SHIFT	(ButtonPano__3__SHIFT)
#define ButtonPano_3_INTR	((uint16)((uint16)0x0003u << (ButtonPano__3__SHIFT*2u)))

#define ButtonPano_INTR_ALL	 ((uint16)(ButtonPano_0_INTR| ButtonPano_1_INTR| ButtonPano_2_INTR| ButtonPano_3_INTR))


#endif /* End Pins ButtonPano_ALIASES_H */


/* [] END OF FILE */
