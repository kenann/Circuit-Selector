/*******************************************************************************
* File Name: C_Relay.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_C_Relay_ALIASES_H) /* Pins C_Relay_ALIASES_H */
#define CY_PINS_C_Relay_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define C_Relay_0			(C_Relay__0__PC)
#define C_Relay_0_PS		(C_Relay__0__PS)
#define C_Relay_0_PC		(C_Relay__0__PC)
#define C_Relay_0_DR		(C_Relay__0__DR)
#define C_Relay_0_SHIFT	(C_Relay__0__SHIFT)
#define C_Relay_0_INTR	((uint16)((uint16)0x0003u << (C_Relay__0__SHIFT*2u)))

#define C_Relay_1			(C_Relay__1__PC)
#define C_Relay_1_PS		(C_Relay__1__PS)
#define C_Relay_1_PC		(C_Relay__1__PC)
#define C_Relay_1_DR		(C_Relay__1__DR)
#define C_Relay_1_SHIFT	(C_Relay__1__SHIFT)
#define C_Relay_1_INTR	((uint16)((uint16)0x0003u << (C_Relay__1__SHIFT*2u)))

#define C_Relay_2			(C_Relay__2__PC)
#define C_Relay_2_PS		(C_Relay__2__PS)
#define C_Relay_2_PC		(C_Relay__2__PC)
#define C_Relay_2_DR		(C_Relay__2__DR)
#define C_Relay_2_SHIFT	(C_Relay__2__SHIFT)
#define C_Relay_2_INTR	((uint16)((uint16)0x0003u << (C_Relay__2__SHIFT*2u)))

#define C_Relay_3			(C_Relay__3__PC)
#define C_Relay_3_PS		(C_Relay__3__PS)
#define C_Relay_3_PC		(C_Relay__3__PC)
#define C_Relay_3_DR		(C_Relay__3__DR)
#define C_Relay_3_SHIFT	(C_Relay__3__SHIFT)
#define C_Relay_3_INTR	((uint16)((uint16)0x0003u << (C_Relay__3__SHIFT*2u)))

#define C_Relay_INTR_ALL	 ((uint16)(C_Relay_0_INTR| C_Relay_1_INTR| C_Relay_2_INTR| C_Relay_3_INTR))


#endif /* End Pins C_Relay_ALIASES_H */


/* [] END OF FILE */
