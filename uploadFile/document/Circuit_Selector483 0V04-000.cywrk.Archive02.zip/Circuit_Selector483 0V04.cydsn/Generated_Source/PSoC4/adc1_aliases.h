/*******************************************************************************
* File Name: adc1.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_adc1_ALIASES_H) /* Pins adc1_ALIASES_H */
#define CY_PINS_adc1_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define adc1_0			(adc1__0__PC)
#define adc1_0_PS		(adc1__0__PS)
#define adc1_0_PC		(adc1__0__PC)
#define adc1_0_DR		(adc1__0__DR)
#define adc1_0_SHIFT	(adc1__0__SHIFT)
#define adc1_0_INTR	((uint16)((uint16)0x0003u << (adc1__0__SHIFT*2u)))

#define adc1_INTR_ALL	 ((uint16)(adc1_0_INTR))


#endif /* End Pins adc1_ALIASES_H */


/* [] END OF FILE */
