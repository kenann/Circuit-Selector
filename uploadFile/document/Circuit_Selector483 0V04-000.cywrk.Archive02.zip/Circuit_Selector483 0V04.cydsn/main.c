/* ========================================

yağmur oldum toprağa geldim
zerre oldum maddeye geldim
ruh oldum cana üflendim
emdim insana geldim
koştum sana ulaştım
gördüm aşk'a erdim
bildim sen oldum

Selector Cabin (SC)
*Temel olarak, CCR çıkışını birden farklı yönlere çevirebilen özelliktedir.
*Yön değiştirmeden önce CCR kapatıp yön değiştiğinde tekrar açar.
*Otomatik kontrol modunda CCR durumuna göre Kontrol modu değişebilir.
*Kule kontrol modundayken yeni bir sinyal gelene kadar son durumunu korur. Çift sinyal ve benzeri durumlarda son durumunu değiştirmez.

* 4 yönlü olarak tasarlanmıştır. 
-Seçici modundayken sadece 1. ve 2. kontaktörler kullanılabilir.
-Yönlendirici modundayken her kontaktör ayrı ayrı çalıştırılabilir.

* Selektor kontrol modu olarak 3 davranış seçilebilir. Ön kapakta Rotary Çevirilerek "Rem-Auto-Manuel" seçilebilir. 
** SC kartında "CCR_Monitor_Rem_Loc" girişine CCR remote çıkışının bağlanması gerekir. Bağlantı yapılmazsa "Manuel" kontrol modunda kalır.
-"Rem" kontrol modu seçilirse CCR remote kontrol moduna alınması gerekir.
-"Auto" kontrol modu seçilirse CCR durumuna göre SC otomatik olarak "Rem" veya "Manuel" kontrol moduna geçer.
-"Manuel" kontrol modu seçilirse CCR manuel kontrol moduna alınması gerekir.

/////////////////////////////////////////////////////////////////////////////////
*SC kartına Yapılması zorunlu bağlantılar.

-J12 Front Panel Konnektörü
--Local_Rotary,--Remote_Rotary,--CCR_Remote_Rotary
--Local_Lamp,--CCR_Remote_Lamp,--Remote_Lamp
--K1_Buttom,--K2_Buttom,--K3_Buttom,--K4_Buttom

-J1 CCR'ın sahaya elektrik verdiği ve CCR'ın Kule kontrolüne alındığı bilgisi için
--CCR_Monitor_Com(1.pim ve 2.pim),--CCR_Monitor_Off,--CCR_Monitor_Rem_Loc

-J2 CCR Kontrol Konnektörü (CCR Kontrol durumuna göre NO veya NC seçilebilir)
--CCI(CCR Com ucu), --CCR_On_NC, --CCR_On_NO

-J3 Kule Kontrol Girişi. Bu girişi "24V ve 48V" göre tasarlanmıştır. Dahili 24V beslemesi kullanılacaksa 2-4 arasın kablo ile bir birine bağlanarak 3 numaralı giriş ucu kontrol ucu olarak kullanılmalıdır.
--C1, --C2, --C3, --C4 ucu Kule konrol ucu olarak kullanılır.
/////////////////////////////////////////////////////////////////////////////////

 * ========================================
*/
#include "project.h"
   
    uint8 test1, test2;

uint8 selector_mode = 0u, selectstart_contact = 0u, Tower_isr_flag = 0u, Buttonn_isr_flag = 0u, timer_isr_flagOK = 0u;
uint8 remote_temp = 0, local_temp = 0u;
uint8 uni_temp = 0u, uni_Downcounter = 0u;
uint16 timer_period = 16000;

uint16 initial_delay = 500u;//sistem başlarken röle ve girişleri beklemesi için
uint16 CCR_Monitor_OFF_NO_Delay = 1000u;//regülatörün kapanma açılması için bekleme süresi
uint8 Kontaktor_Write_Delay = 250u;// regülatör kapandıktan sonra Yön seçimi için bekleme süresi

CY_ISR(Tower_isr)//Remote
{   
    uni_temp = Tower_Read();
    Timer_cpu_Stop();
    
    if(uni_temp <= 0x0f)
    {
        //uni_temp = (~uni_temp) & 0x0f; //tersini almak için
        if(remote_temp != uni_temp)
        {
            remote_temp = uni_temp;
            Tower_isr_flag = 1u;            
        }else Tower_isr_flag = 0u;
    }
    uni_temp = 0u;
    timer_isr_flagOK = 1u;
    
    Tower_ClearInterrupt();    
    isr_Towerr_ClearPending();
}
CY_ISR(Buttonn_isr)//Buttom
{
    //select_temp_isr = (~Butonn_Read()) & 0x0f;    
    uni_temp = Butonn_Read();
    
    if(uni_temp < 0x0f && CCR_Monitor_OFF_NO_Read()) {
        local_temp = (uni_temp & 0x0f);
        uni_Downcounter = 101u;
       
        do{ //buton basılma kontrolü
            uni_Downcounter--;
            CyDelay(10);
            uni_temp = (~Butonn_Read() & 0x0f);
        }while((uni_temp != 0x00) && (uni_Downcounter > 0u));
        
        if(uni_Downcounter == 0u)Buttonn_isr_flag = 0u;
        else Buttonn_isr_flag = 1u;
        
        uni_temp = 0u;
        uni_Downcounter = 0u;
    }
    else local_temp = Kontaktor_Read();
    
    isr_Buttonn_ClearPending();
    Butonn_ClearInterrupt();
}
void Tower_isr_clear(void)
{
    Tower_ClearInterrupt();    
    isr_Towerr_ClearPending();

    Timer_cpu_ClearFIFO();
    Timer_cpu_ReadStatusRegister();
    Timer_cpu_WritePeriod(timer_period);
    Timer_cpu_Start();    
}
uint8 remote_state_control(void)
{
    uint8 remote_security_return = 1u;
    if(isr_Buttonn_GetState() || Butonn_ClearInterrupt()) {//Kesme kapalı ama butona basıldıysa temizler    
        isr_Buttonn_Disable();        
            timer_isr_flagOK = 0u;
            Buttonn_isr_flag = 0u;        
        isr_Buttonn_ClearPending();
            Butonn_ClearInterrupt();  
    }
    
    if(CCR_Monitor_Rem_Loc_NO_Read()== 0u) {
        Remote_Lamp_Uln_Write(1); 
        CyDelay(250); 
        Remote_Lamp_Uln_Write(0); 
        CyDelay(250);
        remote_security_return = 0u;//Return
    }
    else if(!Remote_Lamp_Uln_Read()) {              
        Remote_Lamp_Uln_Write(1);    
        remote_security_return = 0u;//Return
    }
    else if(isr_Towerr_GetState() == 0u) {
        timer_isr_flagOK = 0u;
        Tower_isr_flag = 0u;
        
        Tower_isr_clear();
        isr_Towerr_Enable(); 
        
        remote_temp = Kontaktor_Read();//sistem tekrar Remote alındığında giriş ve çıkışları karşılaştırması için
        
        isr_Towerr_SetPending();  
        
        remote_security_return = 1u;//Return
    }    
    return remote_security_return;
}
uint8 local_state_control(void)
{
    uint8 local_security_return = 1u;
    if(isr_Towerr_GetState() || Tower_ClearInterrupt()) {
        isr_Towerr_Disable();
        
        timer_isr_flagOK = 0u;
        Tower_isr_flag = 0u;

        Timer_cpu_Stop();
        
        Tower_ClearInterrupt();    
        isr_Towerr_ClearPending(); 
    }
    if(isr_Buttonn_GetState() == 0u) {             
        timer_isr_flagOK = 0u;
        Buttonn_isr_flag = 0u;
        
        isr_Buttonn_ClearPending();
        Butonn_ClearInterrupt();
        isr_Buttonn_Enable(); 
    }
    if(CCR_Monitor_Rem_Loc_NO_Read()== 1u) {
        Local_Lamp_Uln_Write(1); 
        CyDelay(250); 
        Local_Lamp_Uln_Write(0); 
        CyDelay(250);
        local_security_return = 0u;//return 0;
    }
    else if(!Local_Lamp_Uln_Read()) {
        Local_Lamp_Uln_Write(1);
        local_security_return = 1u;//return 1;
    }
    return local_security_return;
}
uint8 security(void)
{
    /*
    Döngü anında olabilecek sıra dışı durumları kontrol ederek, olabilecek sorunları temizler.
    Kule kontrolündeyken butona basılırsa veya Buton konrolündeyken Kuleden bilgi gelirse kesme ve değişkenleri temizler
    Kule kontrol modunda ve CCR Manuel moddaysa Pano ışıklarından uyarı veriri, her fonksiyonun kendi içinde dir.
    Manuel kontrol modunda ve CCR Remote moddyasa Pano ışıklarından uyarı veriri, her fonksiyonun kendi içinde dir.
    */
    uint8 security_return = 1u;
    if(!Remote_Rotary_opto_Read()) {
        security_return = remote_state_control();
    }
    else if(!Local_Rotary_opto_Read()) {
        security_return = local_state_control();
    }
    else if(Remote_Rotary_opto_Read() && Local_Rotary_opto_Read()) {
        if(CCR_Monitor_Rem_Loc_NO_Read()) {//Auto Remote 
            security_return = remote_state_control();
        }
        else if(!CCR_Monitor_Rem_Loc_NO_Read()) {//Auto Local        
            security_return = local_state_control();
        }
    }
    return security_return;
}
uint8 direct_contact(uint8 direct_temp)//Devre seçici
{
    direct_temp = (~direct_temp) & 0x03;
        if(CCR_Monitor_OFF_NO_Read() == 1u) {
            if(direct_temp == 1u)  {
                CyDelay(Kontaktor_Write_Delay);
                Kontaktor_Write(0x0E);//Sahaya giden diğer devrelerin açılmaması için 11110 
            }
            else if(direct_temp == 2u) {
                CyDelay(Kontaktor_Write_Delay);
                Kontaktor_Write(0x0D);//Sahaya giden diğer devrelerin açılmaması için 11101 
            }
                        
            if(!Remote_Rotary_opto_Read() || !Local_Rotary_opto_Read()) {//Sadece Remote modda gerekiyor   
                CyDelay(CCR_Monitor_OFF_NO_Delay); 
            }
            
            uni_Downcounter = 5u;
            do {
                CyDelay(100);
                CCR_Control_On_Off_Uln_Write(0); 
                uni_Downcounter--;
                direct_temp = CCR_Monitor_OFF_NO_Read();
                
            }while((direct_temp == 0u) && (uni_Downcounter > 0u));            
            if(uni_Downcounter == 0u)return 1; 
            uni_Downcounter = 0u;
            
            return 0u;
        }
        else if(direct_temp != Kontaktor_Read()) {// aynı değer geldiğinde regülatör kapanmasın diye
        
            if((direct_temp < 3u) && (direct_temp > 0u)) {//uzak kukandada yön bilgisinin rastgele durmunu kontrol etmek için
                CCR_Control_On_Off_Uln_Write(1); //yön değiştirme de diğer yöne geçmek için
                return 1u;
            }
            else return 0;
        }
        else  return 0u;// bilinmeyen durumlar için çıkış
}
uint8 select_contact(uint8 select_temp)//Yön seçici
{   
    if(Selector_Direct_Read() == 0u) 
    {   
       if(Tower_isr_flag){
            CyDelay(250);
            Kontaktor_Write(select_temp);            
        }
        else if(Buttonn_isr_flag) {
            select_temp = (~select_temp) & 0x0f;
            uni_temp = Kontaktor_Read();//test anında görüntüleyebilmek için sadece
            
            select_temp = select_temp ^ uni_temp;
            CyDelay(250);
            Kontaktor_Write(select_temp);                  
        }
        else Kontaktor_Write(0xf);
        
        if(!Remote_Rotary_opto_Read() || !Local_Rotary_opto_Read()) {//Sadece Remote modda gerekiyor  
           
            CyDelay(CCR_Monitor_OFF_NO_Delay); 
        }
        return 0u;       
    }
    else {
        return 1u;
    }
}
void initial_remote(void)
{
    //remote_temp = (~Tower_Read()) & 0x0f; //tersini almak için
    remote_temp = Tower_Read() & 0x0f;
    if((remote_temp == 0x0f) && (selectstart_contact == 1u)) {
            remote_temp = 0x0e; 
            Tower_isr_flag = 1u;
        }
        
    else if((remote_temp == 0x0f) && (selectstart_contact == 0u)) {
            remote_temp = 0x0d; 
            Tower_isr_flag = 1u;
        }
        
    else {
            remote_temp = Tower_Read(); 
            Tower_isr_flag = 1u;
        }
    
}
void initial_local(void)
{
    //local_temp = (~Butonn_Read()) & 0x0f; //tersini almak için
    local_temp = Butonn_Read() & 0x0f;
    if((local_temp == 0x0f)  && (selectstart_contact == 0u)) {
            local_temp = 0x0e;
            Buttonn_isr_flag = 1u;
        }
        
    else if((local_temp == 0x0f)  && (selectstart_contact == 1u)) {
            local_temp = 0x0d;
            Buttonn_isr_flag = 1u;
        }
        
    else {
        local_temp = Butonn_Read();
        Buttonn_isr_flag = 1u;
    }
    
}
void read_start_state(void)
{
    if(!Remote_Rotary_opto_Read()) { //kuleden gelen yönü seçmek için
    initial_remote();}
    else if(!Local_Rotary_opto_Read()) {//buton dan gelen yönü seçmek için
    initial_local();}
    else if(Remote_Rotary_opto_Read() && Local_Rotary_opto_Read()){//Otomatik seçim    
        if(CCR_Monitor_Rem_Loc_NO_Read()) {//Auto Remote 
        initial_remote();}
        else if(!CCR_Monitor_Rem_Loc_NO_Read()) {//Auto Local
        initial_local();}
    }
}
void initial_ISR(void)
{
    isr_Towerr_StartEx(&Tower_isr);
    Tower_isr_clear();
    
    isr_Buttonn_StartEx(&Buttonn_isr);
    isr_Buttonn_ClearPending();
    Butonn_ClearInterrupt();
}
int main(void) 
{
    CyDelay(initial_delay);//Başlangıç okumadan röle bilgilerini kaçırmaması için
    
    Kontaktor_Write(0x0f);
    selector_mode = Selector_Direct_Read();//yön seçici veya yönlendirici olarak çalışması için
    selectstart_contact = SelectStart_contact_Read();//Başlangıçta hangi kontaktörün çalışacağına karar verir
    
    initial_ISR();//kesmeleri hazırla
    CyGlobalIntEnable;
    
    Error_Flash_Write(0u); // Pano kapağında ki ışıkların son durmu için
    read_start_state();//ilk durumu kontrol et
    
    for(;;) {
        selector_mode = Selector_Direct_Read();//yön seçici veya yönlendirici olarak çalışması için
        if(security()) {
           if(!Remote_Rotary_opto_Read())//kuleden gelen yönü seçmek için        
            {
                if(selector_mode) {//yönlendirme modu
                    if((~Tower_Read() & 0x0f) != (~Kontaktor_Read() & 0x03)) {//Kuleden gelen yön ile kontaktör farklıysa 
                            Tower_isr_flag = 1; 
                            remote_temp = Tower_Read();
                        }
                    if(Tower_isr_flag)    Tower_isr_flag = direct_contact(remote_temp);//kesme geldiğinde
                    if(!Tower_isr_flag)Tower_isr_clear();//Kesme işareti ve Timer temizleme
                }
                else if(!selector_mode && Tower_isr_flag) {
                    Tower_isr_flag = select_contact(remote_temp);
                }
                timer_isr_flagOK = 0u; 
            }
           else if(!Local_Rotary_opto_Read() && Buttonn_isr_flag)//buton dan gelen yönü seçmek için        
            {//Direct mode
                if(selector_mode)Buttonn_isr_flag = direct_contact(local_temp);
                else Buttonn_isr_flag = select_contact(local_temp);
                timer_isr_flagOK = 0u;
            }
           else if(Remote_Rotary_opto_Read() && Local_Rotary_opto_Read())//Otomatik seçim
            {                
                if(CCR_Monitor_Rem_Loc_NO_Read())//Otomatik seçim - kuleden gelen yönü seçmek için        
                {
                    if(selector_mode) {//yönlendirme modu
                    
                        if((~Tower_Read() & 0x0f) != (~Kontaktor_Read() & 0x03)) {//Kuleden gelen yön ile kontaktör farklıysa 
                            Tower_isr_flag = 1; 
                            remote_temp = Tower_Read();
                        }
                        if(Tower_isr_flag)    Tower_isr_flag = direct_contact(remote_temp);//kesme geldiğinde
                        if(!Tower_isr_flag)Tower_isr_clear();//Kesme işareti ve Timer temizleme
                    }
                    else if(!selector_mode && Tower_isr_flag) {//seçici modu
                    
                        Tower_isr_flag = select_contact(remote_temp);
                    }
                    timer_isr_flagOK = 0u;               
                }
                else if(!CCR_Monitor_Rem_Loc_NO_Read())//Otomatik seçim - buton dan gelen yönü seçmek için    
                {
                    if(Buttonn_isr_flag)    
                    {
                        if(selector_mode)Buttonn_isr_flag = direct_contact(local_temp);
                        else if(!selector_mode) Buttonn_isr_flag = select_contact(local_temp);
                        
                        timer_isr_flagOK = 0u;
                    }
                }
            }
        CSS_Error_Write(0u);
        }    
        else{CSS_Error_Write(1u);}
    }
}

/* [] END OF FILE */
