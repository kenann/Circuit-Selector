/*******************************************************************************
* File Name: Butonn.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Butonn_H) /* Pins Butonn_H */
#define CY_PINS_Butonn_H

#include "cytypes.h"
#include "cyfitter.h"
#include "Butonn_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} Butonn_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   Butonn_Read(void);
void    Butonn_Write(uint8 value);
uint8   Butonn_ReadDataReg(void);
#if defined(Butonn__PC) || (CY_PSOC4_4200L) 
    void    Butonn_SetDriveMode(uint8 mode);
#endif
void    Butonn_SetInterruptMode(uint16 position, uint16 mode);
uint8   Butonn_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void Butonn_Sleep(void); 
void Butonn_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(Butonn__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define Butonn_DRIVE_MODE_BITS        (3)
    #define Butonn_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - Butonn_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the Butonn_SetDriveMode() function.
         *  @{
         */
        #define Butonn_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define Butonn_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define Butonn_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define Butonn_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define Butonn_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define Butonn_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define Butonn_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define Butonn_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define Butonn_MASK               Butonn__MASK
#define Butonn_SHIFT              Butonn__SHIFT
#define Butonn_WIDTH              4u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Butonn_SetInterruptMode() function.
     *  @{
     */
        #define Butonn_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define Butonn_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define Butonn_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define Butonn_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(Butonn__SIO)
    #define Butonn_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(Butonn__PC) && (CY_PSOC4_4200L)
    #define Butonn_USBIO_ENABLE               ((uint32)0x80000000u)
    #define Butonn_USBIO_DISABLE              ((uint32)(~Butonn_USBIO_ENABLE))
    #define Butonn_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define Butonn_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define Butonn_USBIO_ENTER_SLEEP          ((uint32)((1u << Butonn_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << Butonn_USBIO_SUSPEND_DEL_SHIFT)))
    #define Butonn_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << Butonn_USBIO_SUSPEND_SHIFT)))
    #define Butonn_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << Butonn_USBIO_SUSPEND_DEL_SHIFT)))
    #define Butonn_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(Butonn__PC)
    /* Port Configuration */
    #define Butonn_PC                 (* (reg32 *) Butonn__PC)
#endif
/* Pin State */
#define Butonn_PS                     (* (reg32 *) Butonn__PS)
/* Data Register */
#define Butonn_DR                     (* (reg32 *) Butonn__DR)
/* Input Buffer Disable Override */
#define Butonn_INP_DIS                (* (reg32 *) Butonn__PC2)

/* Interrupt configuration Registers */
#define Butonn_INTCFG                 (* (reg32 *) Butonn__INTCFG)
#define Butonn_INTSTAT                (* (reg32 *) Butonn__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define Butonn_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(Butonn__SIO)
    #define Butonn_SIO_REG            (* (reg32 *) Butonn__SIO)
#endif /* (Butonn__SIO_CFG) */

/* USBIO registers */
#if !defined(Butonn__PC) && (CY_PSOC4_4200L)
    #define Butonn_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define Butonn_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define Butonn_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define Butonn_DRIVE_MODE_SHIFT       (0x00u)
#define Butonn_DRIVE_MODE_MASK        (0x07u << Butonn_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins Butonn_H */


/* [] END OF FILE */
